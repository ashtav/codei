<script src="<?= url('assets/js/libraries/jquery-3.2.1.min.js') ?>"></script>
<script src="<?= url('assets/js/libraries/bootstrap.bundle.min.js') ?>"></script>

<!-- <script src="./assets/js/build/script.js" charset="utf-8"></script> -->
<script src="<?= url('assets/js/services/helper.js') ?>" charset="utf-8"></script>
