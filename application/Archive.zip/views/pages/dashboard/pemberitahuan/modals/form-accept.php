<div class="modal fade" id="form-accept" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Title</h5>
        <button type="button" class="close no-outline" data-dismiss="modal" aria-label="Close"></button>
      </div>

      <form>
        <div class="modal-body">

          <div class="form-group">
            <textarea class="form-control" name="keterangan" placeholder="Inputkan keterangan (ex: 08:00 - 08:30)" required style="min-height: 150px"></textarea>
          </div>

        </div>
        <div class="modal-footer">
          <div class="btn-group">
            <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Batal</button>
            <button type="submit" class="btn btn-outline-primary">Terima</button>
          </div>
        </div>
      </form>

    </div>
  </div>
</div>
