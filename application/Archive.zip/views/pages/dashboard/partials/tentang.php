<div class="modal fade" id="form-about" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Tentang Aplikasi</h5>
        <button type="button" class="close no-outline" data-dismiss="modal" aria-label="Close"></button>
      </div>

      <form>
        <div class="modal-body">
          <b>Medic</b> adalah aplikasi layanan pemeriksaan dokter dan laboratorium yang dibuat untuk membudahkan pasien dalam memesan layanan rumah sakit. Aplikasi ini dibuat dalam rangka guna memenuhi syarat untuk lulus sebagai sarjana. <br><br>Version 1.0.0
        </div>
        <div class="modal-footer">
          <div class="btn-group">
            <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Tutup</button>
          </div>
        </div>
      </form>

    </div>
  </div>
</div>
